/****************************************************************************
** Meta object code from reading C++ file 'monitormaga.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../mAgaMonitor/monitormaga.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'monitormaga.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_mAgaMonitor_t {
    const uint offsetsAndSize[34];
    char stringdata0[373];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_mAgaMonitor_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_mAgaMonitor_t qt_meta_stringdata_mAgaMonitor = {
    {
QT_MOC_LITERAL(0, 11), // "mAgaMonitor"
QT_MOC_LITERAL(12, 8), // "readData"
QT_MOC_LITERAL(21, 0), // ""
QT_MOC_LITERAL(22, 36), // "on_cbxSerialSpeed_currentText..."
QT_MOC_LITERAL(59, 4), // "arg1"
QT_MOC_LITERAL(64, 35), // "on_cbxSerialPort_currentTextC..."
QT_MOC_LITERAL(100, 18), // "on_btnOpen_clicked"
QT_MOC_LITERAL(119, 18), // "on_btnSend_clicked"
QT_MOC_LITERAL(138, 31), // "on_btnRescanSerialPorts_clicked"
QT_MOC_LITERAL(170, 28), // "on_btnClearLogWindow_clicked"
QT_MOC_LITERAL(199, 22), // "on_btnStartBLE_clicked"
QT_MOC_LITERAL(222, 28), // "on_btnStartAdvertise_clicked"
QT_MOC_LITERAL(251, 27), // "on_btnStopAdvertise_clicked"
QT_MOC_LITERAL(279, 23), // "on_btnStartScan_clicked"
QT_MOC_LITERAL(303, 22), // "on_btnStopScan_clicked"
QT_MOC_LITERAL(326, 20), // "on_btnGetMac_clicked"
QT_MOC_LITERAL(347, 25) // "on_btnListDevices_clicked"

    },
    "mAgaMonitor\0readData\0\0"
    "on_cbxSerialSpeed_currentTextChanged\0"
    "arg1\0on_cbxSerialPort_currentTextChanged\0"
    "on_btnOpen_clicked\0on_btnSend_clicked\0"
    "on_btnRescanSerialPorts_clicked\0"
    "on_btnClearLogWindow_clicked\0"
    "on_btnStartBLE_clicked\0"
    "on_btnStartAdvertise_clicked\0"
    "on_btnStopAdvertise_clicked\0"
    "on_btnStartScan_clicked\0on_btnStopScan_clicked\0"
    "on_btnGetMac_clicked\0on_btnListDevices_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_mAgaMonitor[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   98,    2, 0x0a,    1 /* Public */,
       3,    1,   99,    2, 0x08,    2 /* Private */,
       5,    1,  102,    2, 0x08,    4 /* Private */,
       6,    0,  105,    2, 0x08,    6 /* Private */,
       7,    0,  106,    2, 0x08,    7 /* Private */,
       8,    0,  107,    2, 0x08,    8 /* Private */,
       9,    0,  108,    2, 0x08,    9 /* Private */,
      10,    0,  109,    2, 0x08,   10 /* Private */,
      11,    0,  110,    2, 0x08,   11 /* Private */,
      12,    0,  111,    2, 0x08,   12 /* Private */,
      13,    0,  112,    2, 0x08,   13 /* Private */,
      14,    0,  113,    2, 0x08,   14 /* Private */,
      15,    0,  114,    2, 0x08,   15 /* Private */,
      16,    0,  115,    2, 0x08,   16 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void mAgaMonitor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<mAgaMonitor *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->readData(); break;
        case 1: _t->on_cbxSerialSpeed_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->on_cbxSerialPort_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->on_btnOpen_clicked(); break;
        case 4: _t->on_btnSend_clicked(); break;
        case 5: _t->on_btnRescanSerialPorts_clicked(); break;
        case 6: _t->on_btnClearLogWindow_clicked(); break;
        case 7: _t->on_btnStartBLE_clicked(); break;
        case 8: _t->on_btnStartAdvertise_clicked(); break;
        case 9: _t->on_btnStopAdvertise_clicked(); break;
        case 10: _t->on_btnStartScan_clicked(); break;
        case 11: _t->on_btnStopScan_clicked(); break;
        case 12: _t->on_btnGetMac_clicked(); break;
        case 13: _t->on_btnListDevices_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject mAgaMonitor::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_mAgaMonitor.offsetsAndSize,
    qt_meta_data_mAgaMonitor,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_mAgaMonitor_t
, QtPrivate::TypeAndForceComplete<mAgaMonitor, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *mAgaMonitor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *mAgaMonitor::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_mAgaMonitor.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int mAgaMonitor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 14;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
